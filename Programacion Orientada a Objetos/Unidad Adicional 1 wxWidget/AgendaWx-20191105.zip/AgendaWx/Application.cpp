#include "Application.h"
#include "WinPrincipal.h"
#include "Agenda.h"

Application::Application() : m_agenda("datos.dat") {
	
}

/**
* Este metodo hace las veces del main, y debe inicializar el programa. Esto es,
* crear una instancia de agenda, cargar la base de datos desde el archivo 
* binario, crear la primer ventana y mostrarla.
**/
bool Application::OnInit() {
	WinPrincipal *v = new WinPrincipal(&m_agenda); // crear la primer ventana
	v->Show(); // mostrar la ventana
	return true; // true indica que todo se inicializo sin problemas
}


