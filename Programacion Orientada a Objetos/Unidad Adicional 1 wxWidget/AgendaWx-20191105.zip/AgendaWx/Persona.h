/**
* @file Persona.h
* @brief Declaraciones de todo lo necesario para trabajar con la clase Persona
*
* Este archivo define la clase Persona, las funciones auxiliares para compararlas
* y el struct que hace de intermediario para guardar y leer en archivo binarios.
**/
#ifndef PERSONA_H
#define PERSONA_H
#include <string>
#include <fstream>

/**
* @brief Estructura auxiliar para usar con archivos binarios
*
* En los binarios no se debe guardar ni escribir objetos string porque al ser
* dinamicos contienen punteros y lo que en realidad se guardaria seria el
* puntero y no la informacion a la que apunta. Esta estructura sirve de 
* intermediaria para guardar y escribir los datos de una persona.
**/
struct registro_persona {
	char nombre[256];
	char apellido[256];
	char telefono[256];
	char direccion[256];
	char localidad[256];
	char email[256];
	int dia_nac, mes_nac, anio_nac;
};


/**
* @brief Clase que representa a una persona. 
*
* Contiene los atributos que se guardan de cada persona, metodos para definirlos
* y modificarlos, para validar los datos, y para guardar o escribir en archivos
* binarios.
**/
class Persona {
	
private:
	
	// datos de una persona
	std::string nombre; ///< nombres de la persona
	std::string apellido; ///< apellido de la persona
	std::string telefono; ///< telefono de la persona
	std::string direccion; ///< direccion de la persona
	std::string localidad; ///< localidad donde vive la persona
	std::string email; ///< direccion de correo electronico de la persona
	int dia_nac; ///< dia de la fecha de naciemiento
	int mes_nac; ///< mes de la fecha de naciemiento
	int anio_nac; ///< a�o de la fecha de naciemiento 
	
public:
	
	// construir un obejto con los datos
	/// Inicializa los datos de una persona
	Persona(std::string a_nombre="", std::string a_apellido="", std::string a_telefono="",
			std::string a_direccion="", std::string a_localidad="", std::string a_email="", 
			int a_dia=0, int a_mes=0, int a_anio=0);

	/// Valida que los datos cargados sean correctos y suficientes
	std::string ValidarDatos();
	
	// obtener los datos guardados
	std::string VerNombre() const; ///< devuelve el nombre de la persona
	std::string VerApellido() const; ///< devuelve el apellido de la persona
	std::string VerDireccion() const; ///< devuelve la direccion de la persona
	std::string VerLocalidad() const; ///< devuelve la localidad de la persona
	std::string VerTelefono() const; ///< devuelve el telefono de la persona
	std::string VerEmail() const; ///< devuelve la direccion de correo electronico de la persona
	int VerDiaNac() const; ///< devuelve el dia de nacimiento de la persona
	int VerMesNac() const; ///< devuelve el mes de nacimiento de la persona
	int VerAnioNac() const; ///< devuelve el anio de nacimiento de la persona
	
	// modificar los datos
	void ModificarNombre(std::string a_nombre); ///< actualiza el nombre de la persona
	void ModificarApellido(std::string a_apellido); ///< actualiza el apellido de la persona
	void ModificarDireccion(std::string a_direccion); ///< actualiza la direccion de la persona
	void ModificarLocalidad(std::string a_localidad); ///< actualiza la localidad de la persona
	void ModificarTelefono(std::string a_telefono); ///< actualiza el telefono de la persona
	void ModificarEmail(std::string a_email); ///< actualiza la direccion de correo electronico de la persona
	void ModificarFechaNac(int a_dia, int a_mes, int a_anio); ///< actualiza la fecha de nacimiento de la persona
	
	
	/// guarda su registro en un archivo binario
	void GuardarEnBinario(std::ofstream &archivo);
	/// lee su registro desde un archivo binario
	void LeerDesdeBinario(std::ifstream &archivo);

};

// crirerios para comparar dos personas

/// @brief Funcion para comparar dos personas por nombre y apellido 
bool criterio_comparacion_apellido_y_nombre(const Persona &p1, const Persona &p2);
/// @brief Funcion para comparar personas por direccion
bool criterio_comparacion_direccion(const Persona &p1, const Persona &p2);
/// @brief Funcion para comparar dos personas por telefono
bool criterio_comparacion_telefono(const Persona &p1, const Persona &p2);
/// @brief Funcion para comparar dos personas por email
bool criterio_comparacion_email(const Persona &p1, const Persona &p2);

#endif

