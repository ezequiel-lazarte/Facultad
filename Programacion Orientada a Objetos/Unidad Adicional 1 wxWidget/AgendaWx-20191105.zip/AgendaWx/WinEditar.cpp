/**
* @file WinEditar.cpp
* @brief Implementa los eventos de la ventana para modificar personas existentes
**/
#include <wx/msgdlg.h>
#include "WinEditar.h"
#include "Persona.h"
#include "Agenda.h"
#include "string_conv.h"

/**
* Carga los datos de una persona de la agenda en los cuadros de texto de la ventana
* @param agenda Puntero a la instancia de Agenda que gestiona todos los datos
* @param parent La ventana de la cual se desprende esta, siempre sera la principal
* @param cual el indice en el arreglo de personas (base 0) de la persona a modificar
**/
WinEditar::WinEditar(wxWindow *parent, Agenda *agenda, int cual) 
	: WxfbPersona(parent), m_agenda(agenda), m_indice_persona(cual)
{
	Persona &p=(*m_agenda)[cual];
	m_nombre->SetValue( std_to_wx(p.VerNombre()) );
	m_apellido->SetValue( std_to_wx(p.VerApellido()) );
	m_telefono->SetValue( std_to_wx(p.VerTelefono()) );
	m_direccion->SetValue( std_to_wx(p.VerDireccion()) );
	m_localidad->SetValue( std_to_wx(p.VerLocalidad()) );
	m_email->SetValue( std_to_wx(p.VerEmail()) );
	if (p.VerAnioNac()!=0) m_anio->SetValue( wxString()<<p.VerAnioNac() );
	if (p.VerMesNac()!=0) m_mes->SetValue( wxString()<<p.VerMesNac() );
	if (p.VerDiaNac()!=0) m_dia->SetValue( wxString()<<p.VerDiaNac() );
	m_boton1->SetLabel("Volver");
	m_boton2->SetLabel("Guardar");
	SetTitle("Editar Persona");
}

void WinEditar::OnClickBoton1( wxCommandEvent& event ) {
	EndModal(0);
}

void WinEditar::OnClickBoton2( wxCommandEvent& event ) {
	long dia,mes,anio; // convertir cadenas a numeros
	m_dia->GetValue().ToLong(&dia);
	m_mes->GetValue().ToLong(&mes);
	m_anio->GetValue().ToLong(&anio);
	Persona p( // crear la instancia de persona
		wx_to_std(m_nombre->GetValue()),
		wx_to_std(m_apellido->GetValue()),
		wx_to_std(m_telefono->GetValue()),
		wx_to_std(m_direccion->GetValue()),
		wx_to_std(m_localidad->GetValue()),
		wx_to_std(m_email->GetValue()),
		dia,mes,anio);
	std::string errores = p.ValidarDatos();
	if (errores.size()) { // ver si no pasa la validacion
		// la conversi�n mediante wxString::From8BitData es porque usualmente 
		// los std::string utilizan una determinada codificacion para los 
		// caracteres (digamos ASCII), mientras que wxString otra (Unicode)
		wxMessageBox(std_to_wx(errores.c_str()),"Errores",wxOK|wxICON_ERROR,this); // mostrar errores
	} else {
		(*m_agenda)[m_indice_persona]=p; // agregar
		m_agenda->Guardar(); // actualizar el archivo
		EndModal(1); // cerrar indicando que se agrego
	}
}


