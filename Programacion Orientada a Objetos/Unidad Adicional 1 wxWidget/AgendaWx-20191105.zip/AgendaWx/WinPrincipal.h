#ifndef WINPRINCIPAL_H
#define WINPRINCIPAL_H
#include "wxfb_project.h"

// declaracion adelantada de la clase Agenda, para que me 
// deje poner un ptr sin tener que hacer el #include "Agenda.h"
class Agenda; 

/**
* @brief Ventana principal de la aplicacion
*
* Esta clase representa a la primer ventana. Incluye una tabla con algunos datos
* de cada persona, permite ver los demas, editarlos o agregar mediante tres
* botones en su parte posterior; y tiene ademas una barra de busqueda en la
* parte superior.
**/
class WinPrincipal : public WxfbPrincipal {
	
private:
	Agenda *m_agenda;
	// metodos auxiliares
	/// Copia los datos de una persona de la base de datos a la tabla
	void CargarFila(int i);
	
protected:
	void EnterBuscar( wxCommandEvent& event ) ;
	// eventos
	/// Acomoda los tama�os de las columnas de la grilla cuando cambia el tama�o de la ventana
	void OnCambiaTamanio( wxSizeEvent& event );
	/// Busca un nombre en la grilla cuando apretamos enter en el cuadro de busqueda
	void OnEnterBuscar( wxCommandEvent& event );
	/// Busca un nombre en la grilla cuando hacemos click en el boton "Buscar"
	void OnClickBuscar( wxCommandEvent& event );
	/// Abre la ventana para editar una persona cuando se hace doble click sobre la misma
	void OnDobleClickGrilla( wxGridEvent& event );
	/// Reordena la grilla cuando se hace click sobre el titulo de una columno
	void OnClickGrilla( wxGridEvent& event );
	/// Abre el cuadro para agregar una nueva persona a la agenda
	void OnClickAgregar( wxCommandEvent& event );
	/// Abre el cuadro para editar los datos de una persona de la agenda
	void OnClickEditar( wxCommandEvent& event );
	/// Elimina una persona de la agenda
	void OnClickEliminar( wxCommandEvent& event );
	
public:
	/// Inicializa la ventana llenando la grilla con los datos que hay en la agenda
	WinPrincipal(Agenda *agenda);
};

#endif

