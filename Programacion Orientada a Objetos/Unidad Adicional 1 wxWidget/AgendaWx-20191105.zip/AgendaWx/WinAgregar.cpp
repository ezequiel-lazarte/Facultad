/**
* @file WinAgregar.cpp
* @brief Implementa los eventos de la ventana para agregar personas nuevas
**/
#include <wx/msgdlg.h>
#include "WinAgregar.h"
#include "Persona.h"
#include "Agenda.h"
#include "string_conv.h"

WinAgregar::WinAgregar(wxWindow *parent, Agenda *agenda) 
	: WxfbPersona(parent), m_agenda(agenda)
{
	SetTitle("Agregar Persona"); // titulo de la ventana
	m_boton1->SetLabel("Cancelar"); // rotulo boton 1
	m_boton2->SetLabel("Agregar"); // rotulo boton 2
}

void WinAgregar::OnClickBoton1( wxCommandEvent& event ) {
	EndModal(0);
}

void WinAgregar::OnClickBoton2( wxCommandEvent& event ) {
	long dia,mes,anio; // convertir cadenas a numeros
	m_dia->GetValue().ToLong(&dia);
	m_mes->GetValue().ToLong(&mes);
	m_anio->GetValue().ToLong(&anio);
	// los objetos de wx devuelven wxString en lugar de string. Para convertir usamos c_str()
	Persona p( // crear la instancia de persona
		wx_to_std(m_nombre->GetValue()),
		wx_to_std(m_apellido->GetValue()),
		wx_to_std(m_telefono->GetValue()),
		wx_to_std(m_direccion->GetValue()),
		wx_to_std(m_localidad->GetValue()),
		wx_to_std(m_email->GetValue()),
		dia,mes,anio);
	std::string errores = p.ValidarDatos();
	if (errores.size()) { // ver si no pasa la validacion
		// la conversi�n mediante wxString::From8BitData es porque usualmente 
		// los std::string utilizan una determinada codificacion para los 
		// caracteres (digamos ASCII), mientras que wxString otra (Unicode)
		wxMessageBox(std_to_wx(errores),"Errores",wxOK|wxICON_ERROR,this); // mostrar errores
	} else {
		m_agenda->AgregarPersona(p); // agregar
		m_agenda->Guardar(); // actualizar el archivo
		EndModal(1); // cerrar indicando que se agrego
	}
}


