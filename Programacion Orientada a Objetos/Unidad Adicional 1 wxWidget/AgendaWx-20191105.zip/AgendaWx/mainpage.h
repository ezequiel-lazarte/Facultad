// Los comentarios que comienzacon con /// o /** son para que los analice una
// aplicaci�n llamada Doxygen. Esta aplicaci�n analiza el c�digo fuente, extrae
// adem�s de la estructura propia del c�digo descripciones de estos comentarios
// (que incluyen algunas palabras claves precedidas por @), y genera con todo
// eso una documentaci�n interna en formato HTML. Si lo instalan 
// (http://www.doxygen.org), en ZinjaI usen la opci�n "Generar" del sumen� 
// "Generar Documentacion" del men� "Herramientas".

/**
* 
* @mainpage Ejemplo de integracion entre ZinjaI y wxFormBuilder
* 
* Hay dos archivos de proyecto en este ejemplo, uno es solo para probar las clases
* que modelan la agenda (Agenda.zpr) y otro que agrega la interfaz gr�fica (wxAgenda.zpr).
* 
* Para trabajar con la interfaz es necesario instalar wxFormbuilder y wxWidgets. 
* En Windows, los binarios de wxWidgets se incluyen en el complemento de ZinjaI 
* En GNU/Linux, se instala con el gestor de paquetes de su distribucion (apt-get, 
* yum, yast, etc). Para conseguir wxFormBuilder pueden bajarlo desde 
* http://wxformbuilder.org. En todos los sistemas wxformbuilder se instala por
* separado.
*
* La estructura del proyecto completo es la siguiente:
*  - Archivos que modelan el problema de forma independiente de la interfaz
*     - Persona.h y Persona.cpp: clase que representa un registro
*     - Agenda.h y Agenda.cpp: clase que engloba el problema completo (ABM)
*     - Utils.h y Utils.cpp: funciones de utileria
*  - Archivos de integracion con wxFormBuilder: 
*     - Archivo de proyecto para el dise�ador: wxfb_project.fbp
*     - Codigo fuente generado automaticamente: wxfb_project.h, wxfb_project.cpp
*  - Archivos de la interfase, heredados de las clases de wxFormBuilder:
*     - WinPrincipal.h, WinPrincipal.cpp: ventana principal
*     - WinAgregar.h y WinAgregar.cpp: ventana para agregar contactos 
*     - WinEditar.h y WinEditar.cpp: ventana para modificar datos de un contacto
*     - icono.xpm: icono para la ventana principal
*     - string_conv.h y string_conv.cpp: funciones auxiliares para lidiar con las 
*                                        diferencias entre std::string y wxString
*  - Otros archivos:
*     - mainpage.h: Documentacion interna, para usar con Doxygen 
*     - manifest.xml: para indicar a Windows que aplique sus estilos visuales
*     - icono.xpm: �cono para la ventana principal en formato arreglo de c
*     - <a href="../../Tutorial.pdf">Tutorial.pdf</a>: tutorial paso a paso que explica el
*                                                      desarrollo desde cero de este ejemplo.
*
* �ltima revisi�n: 23/11/2017
*
* Copyleft 2017, por Pablo Novara (zaskar_84@yahoo.com.ar)
*
**/
