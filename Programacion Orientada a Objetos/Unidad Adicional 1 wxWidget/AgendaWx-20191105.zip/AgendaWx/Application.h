#ifndef MX_APPLICATION_H
#define MX_APPLICATION_H

#include <wx/app.h>
#include "Agenda.h"

/**
* @brief clase que inicializa la aplicacion
*
* Esta clase es necesaria por el modo de trabajo de wxWidgets. Hace las veces
* del main mediante su metodo OnInit. Es decir, en este proyecto no programamos
* el main porque el main ya esta dentro de la biblioteca wxWidgets. Ese main, lo
* que hace es crear una instancia de esta clase y llamar al metodo OnInit.
**/
class Application : public wxApp {
public:
	Application();
	/// Inicializa el programa
	virtual bool OnInit();
private:
	Agenda m_agenda;
};

IMPLEMENT_APP(Application)

#endif
