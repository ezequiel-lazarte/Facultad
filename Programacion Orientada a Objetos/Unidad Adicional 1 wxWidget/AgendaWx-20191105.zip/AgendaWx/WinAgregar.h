#ifndef WINAGREGAR_H
#define WINAGREGAR_H
#include "wxfb_project.h"

// declaracion adelantada de la clase Agenda, para que me 
// deje poner un ptr sin tener que hacer el #include "Agenda.h"
class Agenda; 

/**
* @brief Ventana cargar los datos de una nueva persona
**/
class WinAgregar : public WxfbPersona {
	
private:
	Agenda *m_agenda;
	
protected:
	/// Cierra la ventana sin agregar el nuevo dato (boton "Cancelar")
	void OnClickBoton1( wxCommandEvent& event );
	/// Guarda el nuevo dato y cierra la ventana (boton "Agregar");
	void OnClickBoton2( wxCommandEvent& event );
	
public:
	WinAgregar(wxWindow *parent, Agenda *agenda);
};

#endif

