#include<iostream>
#include "Agenda.h"
#include <iomanip>
using namespace std;

int main (int argc, char *argv[]) {
	
	Agenda mi_agenda("datos.dat");
	for (int i=0;i<mi_agenda.CantidadDatos();i++) {
		Persona &p = mi_agenda[i];
		cout<<i<<" "<<p.VerApellido()<<", "<<p.VerNombre()<<endl;
	}
	int cual;
	while (true) {
		cout<<endl<<"Ingrese un nro de registro (-1 para salir): ";
		cin>>cual;
		if (cual==-1) break;
		if (cual>=mi_agenda.CantidadDatos()) {
			cout<<"Solo hay "<<mi_agenda.CantidadDatos()<<" registros"<<endl;
			continue;
		}
		Persona &p=mi_agenda[cual];
		cout<<"Nombres: "<<p.VerNombre()<<endl;
		cout<<"Apellido: "<<p.VerApellido()<<endl;
		cout<<"E-mail: "<<p.VerEmail()<<endl;
		cout<<"Telefono: "<<p.VerTelefono()<<endl;
		cout<<"Direccion: "<<p.VerDireccion()<<endl;
		cout<<"Localidad: "<<p.VerLocalidad()<<endl;
		cout<<"Fecha de Nacimiento: "
			<<setw(2)<<p.VerDiaNac()<<"/"
			<<setw(2)<<p.VerMesNac()<<"/"
			<<setw(4)<<p.VerAnioNac()<<endl;
	}
	
	return 0;
}

