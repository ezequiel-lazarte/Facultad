/**
* @file Utils.h
* @brief Funciones varias para simplificar tareas
* 
* En este archivo van las funciones generales. Es decir, las que no son 
* particulares de ninguna clase.
**/

#ifndef UTILS_H
#define UTILS_H

#include <string>

/// Convierte una cadena a solo minusculas
void pasar_a_minusculas(std::string &s);

#endif

