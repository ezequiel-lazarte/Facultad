#ifndef WINEDITAR_H
#define WINEDITAR_H
#include "wxfb_project.h"

// declaracion adelantada de la clase Agenda, para que me 
// deje poner un ptr sin tener que hacer el #include "Agenda.h"
class Agenda; 

/**
* @brief Ventana para ver y/o modificar los datos de una persona existente
**/
class WinEditar : public WxfbPersona {
	
private:
	Agenda *m_agenda;
	int m_indice_persona; ///< guarda el indice de la persona por si hay que modificarla
	
protected:
	/// Cierra la ventana sin modificar los datos (boton "Volver")
	void OnClickBoton1( wxCommandEvent& event );
	/// Guarda los cambios y cierra la ventana (boton "Guardar")
	void OnClickBoton2( wxCommandEvent& event );
	
public:
	/// Carga los datos de una persona en los campos de la ventana
	WinEditar(wxWindow *parent, Agenda *agenda, int cual);
};

#endif

