/**
* @file WinPrincipal.cpp
* @brief Implementa los eventos de la ventana principal del programa
**/
#include <wx/msgdlg.h>
#include <wx/icon.h>
#include "Agenda.h"
#include "Persona.h"
#include "WinPrincipal.h"
#include "WinAgregar.h"
#include "WinEditar.h"
#include "icono.xpm"
#include "string_conv.h"

/**
* Inicializa la ventana, asignandole un icono, llenando la m_grilla y definiendo
* las propiedades adicionales de la tabla.
**/
WinPrincipal::WinPrincipal(Agenda *agenda) 
	: WxfbPrincipal(nullptr), m_agenda(agenda) 
{
	SetIcon(wxIcon(icono_xpm));
	int c_pers = m_agenda->CantidadDatos(); // averiguar cuantas filas va a tener la tabla
	m_grilla->AppendRows(c_pers); // ..agregar las filas (la tabla inicialmente esta vacia)
	for (int i=0;i<c_pers;i++) CargarFila(i);// cargar todos los datos
	m_grilla->SetSelectionMode(wxGrid::wxGridSelectRows); // hacer que la seleccion sea por fila, y no por celda
}

/**
* Toma los datos de una persona desde la instancia de Agenda y los carga en su
* correspondiente fila de la m_grilla. Se usa al cargar por primera vez, al editar,
* o al agregar personas. La m_grilla ya debe tener lugar, es decir, debe existir el
* renglon (estara vacio o tendra basura).
* @param i el indice de la persona en el arreglo de la clase Agenda (en base 0)
**/
void WinPrincipal::CargarFila(int i) {
	Persona &p=(*m_agenda)[i];
	m_grilla->SetCellValue( i, 0, std_to_wx(p.VerApellido()+", "+p.VerNombre()) );
	m_grilla->SetCellValue( i, 1, std_to_wx(p.VerDireccion()) );
	m_grilla->SetCellValue( i, 2, std_to_wx(p.VerTelefono()) );
	m_grilla->SetCellValue( i, 3, std_to_wx(p.VerEmail()) );
}

/**
* Si se hace click en la cabecera de alguna columna, la tabla se ordena segun
* ese dato. Para esto, se le pide a la base de datos que ordene, y luego 
* se recargan los datos de todas las filas.
**/
void WinPrincipal::OnClickGrilla( wxGridEvent& event ) {
	int columna=event.GetCol(), c_pers=m_agenda->CantidadDatos();
	switch(columna) { // ordenar en mi_agenda
		case 0: m_agenda->Ordenar(ORDEN_APELLIDO_Y_NOMBRE); break;
		case 1: m_agenda->Ordenar(ORDEN_DIRECCION); break;
		case 2: m_agenda->Ordenar(ORDEN_TELEFONO); break;
		case 3: m_agenda->Ordenar(ORDEN_EMAIL); break;
	}
	for (int i=0;i<c_pers;i++) CargarFila(i); // actualizar vista
}

/**
* Cuando se hace click en buscar, se busca desde la persona que esta seleccionada
* en la tabla, en adelante, algun nombre y apellido que contenga lo que indica
* el cuadro de busqueda (puede contenerlo en cualquier parte, y la busqueda no
* distingue mayusculas y minusculas).
* Si hay mas de uno que coinciden, cada click en buscar nos lleva al siguiente.
**/
void WinPrincipal::OnClickBuscar( wxCommandEvent& event ) {
	// buscar desde la fila actual
	int fila_actual = m_grilla->GetGridCursorRow();
	if (m_grilla->GetSelectedRows().GetCount()==0) fila_actual=-1;
	int res=m_agenda->BuscarApellidoYNombre( wx_to_std(m_busqueda->GetValue()), fila_actual+1 );
	// si no encontro buscar otra vez desde el principio
	if (res==NO_SE_ENCUENTRA) 
		res=m_agenda->BuscarApellidoYNombre( wx_to_std(m_busqueda->GetValue()), 0 );
	if (res==NO_SE_ENCUENTRA) // si no hay ninguna coincidencia
		wxMessageBox("No se encontraron coincidencias");
	else {
		m_grilla->SetGridCursor(res,0); // seleccionar
		m_grilla->SelectRow(res); // seleccionar
	}
}

/**
* Al hacer click en "Agregar", se abre de forma modal la ventana para ingresar
* los datos. En forma modal significa que esta ventana espera a que termine la
* otra. Cuando termina, el codigo de retorno me indica si la otra ventana agrego
* o no (el usuario puede hacer click en Agregar o en Cancelar) a una nueva
* persona. En caso afirmativo, esta ventana debe actualizar la m_grilla.
**/
void WinPrincipal::OnClickAgregar( wxCommandEvent& event ) {
	WinAgregar nueva_ventana(this,m_agenda); // crear la ventana
	if (nueva_ventana.ShowModal()==1) { // mostrar y esperar
		m_grilla->AppendRows(1); // agregar el lugar en la m_grilla
		int pos_nuevo = m_agenda->CantidadDatos()-1;
		CargarFila(pos_nuevo); // copiar en la m_grilla
		m_grilla->SetGridCursor(pos_nuevo,0); // seleccionar el nuevo registro
		m_grilla->SelectRow(pos_nuevo); // seleccionar el nuevo registro
	}
}

/**
* Al hacer click en "Editar", se abre de forma modal la ventana para ver y/o
* modificar los datos. En forma modal significa que esta ventana espera a que 
* termine la otra. Cuando termina, el codigo de retorno me indica si la otra 
* ventana modifico o no los datos (el usuario puede hacer click en Agregar o
* en Cancelar) En caso afirmativo, esta ventana debe actualizar la m_grilla.
**/
void WinPrincipal::OnClickEditar( wxCommandEvent& event ) {
	int fila_actual = m_grilla->GetGridCursorRow(); // obtener el indice de persona
	WinEditar nueva_ventana(this,m_agenda,fila_actual); // crear la ventana
	if (nueva_ventana.ShowModal()) // mostrar y esperar
		CargarFila(fila_actual); // actualizar en la m_grilla
}

/**
* Cuando se hace click en "Eliminar", primero se pide confirmacion, y en caso
* afirmativo se elimina la persona de la base de datos, y la fila de la tabla.
**/
void WinPrincipal::OnClickEliminar( wxCommandEvent& event ) {
	int fila_actual = m_grilla->GetGridCursorRow();
	int res = wxMessageBox(c_to_wx("�Eliminar el registro?"),m_grilla->GetCellValue(fila_actual,0),wxYES_NO);
	if (res==wxYES) {
		m_grilla->DeleteRows(fila_actual,1);
		m_agenda->EliminarPersona(fila_actual);
		m_agenda->Guardar();
	}
}

/**
* El doble click en la m_grilla equivale al click en el boton "Editar".
**/
void WinPrincipal::OnDobleClickGrilla( wxGridEvent& event ) {
	int fila_actual = m_grilla->GetGridCursorRow(); // obtener el indice de persona
	WinEditar nueva_ventana(this,m_agenda,fila_actual); // crear la ventana
	if (nueva_ventana.ShowModal()) // mostrar y esperar
		CargarFila(fila_actual); // actualizar en la m_grilla
}


/**
* El enter en el cuadro de texto equivale al click en el boton "Buscar".
**/
void WinPrincipal::OnEnterBuscar( wxCommandEvent& event ) {
	OnClickBuscar(event);
}

/**
* Las columnas de la tabla no se ajustan solas cuando se redimensiona la ventana.
* Este metodo calcula los nuevos tama�os proporcionalmente a los viejos para
* que ocupen todo el espacio posible.
**/
void WinPrincipal::OnCambiaTamanio( wxSizeEvent& event ) {
	// si cambia el tamanio de la ventana, estira los anchos de las columnas 
	// para ajustarse al nuevo tama�o de forma proporcional
	Layout(); // primero que ajuste lo de la ventana, asi tengo el nuevo tama�o de la m_grilla
	int tamanios[4], ancho_total_viejo=0; // despues, guardar tamanios viejos
	for (int i=0;i<4;i++) { 
		tamanios[i] = m_grilla->GetColSize(i);
		ancho_total_viejo += tamanios[i];
	}
	int ancho_total_nuevo=m_grilla->GetSize().GetWidth(); // ver el ancho nuevo de la tabla
	m_grilla->BeginBatch(); // beginbatch y endbatch son para que cuando cambiamos varias cosas no redibuje varias veces, sino una sola al final
	for (int i=0;i<4;i++) // asignar nuevos tama�os nuevos a columnas
		m_grilla->SetColSize(i,tamanios[i]*ancho_total_nuevo/ancho_total_viejo);
	m_grilla->EndBatch();
}

void WinPrincipal::EnterBuscar( wxCommandEvent& event )  {
	event.Skip();
}

